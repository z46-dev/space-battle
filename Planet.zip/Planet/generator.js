const canvas = document.querySelector("canvas");
const ctx = canvas.getContext("2d");

function resize() {
    canvas.width = innerWidth * devicePixelRatio;
    canvas.height = innerHeight * devicePixelRatio;

    canvas.lineJoin = canvas.lineCap = "round";
}

window.addEventListener("resize", resize);
resize();

function lerp(a, b, t) {
    return a + (b - a) * t;
}

class Color {
    static cache = new Map();
    static regex = /\w\w/g;

    static mix(primary, secondary, amount) {
        const key = `${primary}${secondary}${amount}`;

        if (Color.cache.has(key)) {
            return Color.cache.get(key);
        }

        const primaryHex = primary.match(Color.regex);
        const secondaryHex = secondary.match(Color.regex);

        const red = Math.round(lerp(parseInt(primaryHex[0], 16), parseInt(secondaryHex[0], 16), amount)).toString(16).padStart(2, "0");
        const green = Math.round(lerp(parseInt(primaryHex[1], 16), parseInt(secondaryHex[1], 16), amount)).toString(16).padStart(2, "0");
        const blue = Math.round(lerp(parseInt(primaryHex[2], 16), parseInt(secondaryHex[2], 16), amount)).toString(16).padStart(2, "0");

        const hex = `#${red}${green}${blue}`;
        Color.cache.set(key, hex);

        return hex;
    }

    static random() {
        return `#${Math.random().toString(16).slice(2, 8)}`;
    }
}

function circle(x, y, radius, color, shader = (x, y) => [0, 0, 0]) {
    const c = new OffscreenCanvas(radius, radius);
    const c2 = c.getContext("2d");

    c2.fillStyle = color;
    c2.beginPath();
    c2.arc(radius / 2, radius / 2, radius / 2, 0, Math.PI * 2);
    c2.fill();

    const imageData = c2.getImageData(0, 0, radius, radius);
    const data = imageData.data;

    for (let i = 0; i < data.length; i += 4) {
        const [red, green, blue] = shader((i / 4) % radius, Math.floor((i / 4) / radius));

        data[i] = red;
        data[i + 1] = green;
        data[i + 2] = blue;
    }

    c2.putImageData(imageData, 0, 0);

    ctx.drawImage(c, x - radius / 2, y - radius / 2);
}

const seed = Date.now() * Math.random();
function generatePlanet() {
    const x = canvas.width / 2;
    const y = canvas.height / 2;
    const size = Math.min(canvas.width, canvas.height) / 3;
    const baseColor = Color.random();

    // Planet
    circle(x, y, size, baseColor, (x, y) => {
        const divisor = size * .1;
        const noise = quickNoise.noise(x / divisor, y / divisor, seed);
        let color = "#000000";

        if (noise < -0.25) {
            // Deep water
            color = Color.mix("#1eaefb", baseColor, .25);
        } else if (noise < .25) {
            // Shallow water
            color = Color.mix("#fff5c1", baseColor, .25);
        } else if (noise < .75) {
            // Beach
            color = Color.mix("#76ef7c", baseColor, .25);
        } else {
            // Land
            color = Color.mix("#16b58d", baseColor, .25);
        }

        // Get RGB values
        const red = parseInt(color.slice(1, 3), 16);
        const green = parseInt(color.slice(3, 5), 16);
        const blue = parseInt(color.slice(5, 7), 16);

        return [red, green, blue];
    });

    // Tile grid, 20x20
    // const count = 512;
    // for (let i = 0; i < count; i++) {
    //     for (let j = 0; j < count; j++) {
    //         const tileSize = 1;
    //         const noiseValue = quickNoise.noise(i / (count / 5), j / (count / 5), seed);
    //         let color = "#000000";

    //         if (noiseValue < -0.25) {
    //             // Deep water
    //             color = Color.mix("#1eaefb", baseColor, .25);
    //         } else if (noiseValue < .25) {
    //             // Shallow water
    //             color = Color.mix("#fff5c1", baseColor, .25);
    //         } else if (noiseValue < .75) {
    //             // Beach
    //             color = Color.mix("#76ef7c", baseColor, .25);
    //         } else {
    //             // Land
    //             color = Color.mix("#16b58d", baseColor, .25);
    //         }

    //         ctx.fillStyle = color;
    //         ctx.fillRect(i * tileSize, j * tileSize, tileSize, tileSize);
    //     }
    // }
}

generatePlanet();